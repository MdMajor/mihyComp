package com.example.request;


import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class UpdateStudentRequest {

	private long id;
	
	private String fname;
	
	private String lname;
	
	private String email;
}
