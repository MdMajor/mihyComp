package com.example.request;


import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class CreateStudentRequest {

	@JsonProperty("fName")
	private String fname;
	
	private String lname;
	
	private String email;
}
