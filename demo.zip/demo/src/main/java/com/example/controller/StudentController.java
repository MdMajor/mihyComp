package com.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.entites.StudentEntity;
import com.example.request.CreateStudentRequest;
import com.example.request.UpdateStudentRequest;
import com.example.service.StudentService;
import com.example.response.StudentResponse;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/student/")
public class StudentController {

	@Autowired
	StudentService studentService;
	
	@GetMapping("/getall")
	public List<StudentResponse> getAllStudents() {
	  List<StudentEntity> studentList = studentService.getAllStudents();
	  List<StudentResponse> studentResponseList = new ArrayList<StudentResponse>();
	  
	  studentList.stream().forEach(student -> {
		   studentResponseList.add(new StudentResponse(student));
	  });

	  return studentResponseList;
	}
	
	@PostMapping("create")
	public StudentResponse CreateStudent(@RequestBody CreateStudentRequest createStudentRequest) {
	 
		 StudentEntity studentEntity = studentService.CreateStudent(createStudentRequest);
		 
		 return new StudentResponse(studentEntity);
}

	
	@PutMapping("update")
	public StudentResponse UpdateStudent(@RequestBody UpdateStudentRequest updateStudentRequest) {
		StudentEntity studentEntity = studentService.UpdateStudent( updateStudentRequest);
		
		return new StudentResponse(studentEntity);
	}
	
	/*@DeleteMapping("delete")
	public String DeleteStudent(@RequestParam long id) {
		return studentService.DeleteStudent(id);
	}*/
	
	@DeleteMapping("delete/{id}")
	public String DeleteStudent(@PathVariable long id) {
		return studentService.DeleteStudent(id);
	}
	
	@GetMapping("getbyfname/{fname}")
	public List<StudentResponse> GetByFname(@PathVariable String fname) {
		List<StudentEntity> studentList = studentService.GetByFname(fname);
		  
		List<StudentResponse> studentResponseList = new ArrayList<StudentResponse>();
		  
		  studentList.stream().forEach(student -> {
			   studentResponseList.add(new StudentResponse(student));
		  });

		  return studentResponseList;
	}
	
	
	@GetMapping("getbyfnameandlname/{fname}/{lname}")
	public StudentResponse GetByFnameAndLname(@PathVariable String fname,@PathVariable String lname) {

		  return new StudentResponse(studentService.GetByFnameAndLname(fname,lname));
	}
}