package com.example.response;

import com.example.entites.StudentEntity;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@AllArgsConstructor
public class StudentResponse {

	private long id;
	
	@JsonProperty("first_name")
	private String fname;
	
	
	private String lname;
	
	private String email;
	
	public StudentResponse(StudentEntity studentEntity) {
		this.id=studentEntity.getId();
		this.fname=studentEntity.getFname();
		this.lname=studentEntity.getLname();
		this.email=studentEntity.getEmail();
	}
}
