package com.example.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.entites.StudentEntity;
import com.example.repository.StudentRepository;
import com.example.request.CreateStudentRequest;
import com.example.request.UpdateStudentRequest;

import java.util.List;


@Service
public class StudentService {

	@Autowired
	StudentRepository studentRepository;
	
	public List<StudentEntity> getAllStudents() {
		return studentRepository.findAll();
	}
	
	
	public StudentEntity CreateStudent(CreateStudentRequest createStudentRequest) {
		
		StudentEntity studentEntity = new StudentEntity(createStudentRequest);
		
		studentEntity = studentRepository.save(studentEntity);
		
		return studentEntity;
		
	}
	
	public StudentEntity UpdateStudent(UpdateStudentRequest updateStudentRequest) {
		StudentEntity studentEntity = studentRepository.findById(updateStudentRequest.getId()).get();
		
		if( updateStudentRequest.getFname() != null && 
				!updateStudentRequest.getFname().isEmpty()) {
			studentEntity.setFname( updateStudentRequest.getFname());
		}
		
		studentEntity = studentRepository.save(studentEntity);
		return studentEntity;
	}
	
	public String DeleteStudent(long id) {
	
	    studentRepository.deleteById(id);	
		return "Student has been deleted Successfully";
	}
	
	public List<StudentEntity> GetByFname(String fname){
		
		return studentRepository.findByFirstName(fname);
	}
	
	public StudentEntity GetByFnameAndLname(String fname,String lname){
		
		return studentRepository.findByFirstNameAndLastName(fname,lname);
	}
}

