package com.example.repository;

import java.util.List;
import java.lang.String;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.entites.StudentEntity;

@Repository
public interface StudentRepository extends JpaRepository<StudentEntity, Long> {

	List<StudentEntity> findByFirstName(String firstname);
	StudentEntity findByFirstNameAndLastName(String fname,String lname);
}
